import React from 'react'

const Cettificate = () => {
  return (
    <div>
      
    </div>
  )
}

export default Cettificate
