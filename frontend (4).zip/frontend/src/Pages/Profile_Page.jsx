import React from "react";
import Navbar from "../components/Homepage/Navbar";
import Details from "../components/Profile_Components/Details";
const Profile_Page = () => {
    return (
    <>
        <Navbar></Navbar>
        <Details></Details>
    </>
    );
};

export default Profile_Page;